//
//  Department.swift
//  WSUAssociateSwift
//
//  Created by Erik Buck on 9/16/19.
//  Copyright © 2019 WSU. All rights reserved.
//

import Foundation

class Department : NSObject {
   @objc var name : String = "No Name"
   
   init(_ name: String) { self.name = name }
    
}
