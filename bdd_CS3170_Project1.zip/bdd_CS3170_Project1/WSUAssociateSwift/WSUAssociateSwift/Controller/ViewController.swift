//
//  ViewController.swift
//  WSUAssociateSwift
//
//  Created by Erik Buck on 9/16/19.
//  Copyright © 2019 WSU. All rights reserved.
//  Modified by Brandon Dave on  2/19/21
//      - Implements an AppDelegate to contain Data about a Model
//      Department and Employee.
//      - TableView is asked whether to display content from
//      departmentTable or employeeTable
//      - Table Count and Sorting are done within the same function
//      - Global variable sortDepartments and sortEmployees store the
//      organized AppDelegate data and is used to output such data
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet var departmentTable : UITableView?
    @IBOutlet var employeeTable : UITableView?
    @IBOutlet var sortDeptButton : UIButton?
    @IBOutlet var sortEmployeeButton : UIButton?
    
    var sortDepartments = Array<Department>()  // mimics AppDelegate creation
    var sortEmployees = Array<NSObject>() // mimics AppDelegate creation
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
   }
   
    //  Returns number of rows in tableview
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView == departmentTable){
            let unsorted = (UIApplication.shared.delegate as! AppDelegate).departments
            sortDepartments = Array(unsorted);
            sortDepartments.sort {
                return ($0.value(forKey: "name") as! String) < ($1.value(forKey:"name") as! String);
            }
            return (UIApplication.shared.delegate as! AppDelegate).departments.count
        }
        else if(tableView == employeeTable){
            let unsorted = (UIApplication.shared.delegate as! AppDelegate).employees
            sortEmployees = Array(unsorted);
            //sortEmployees.sort {
            //    return ($0.value(forKey: "lastName") as! String) < ($1.value(forKey:"lastName") as! String);
            //}
            /*
             BDDave 4/7/21:
                Added functionality below to sort first names as well
                as per requirement of Project01
             */
            sortEmployees.sort {
                if(($0.value(forKey: "lastName") as! String) == ($1.value(forKey:"lastName") as! String) ){
                        return ($0.value(forKey: "firstName") as! String) < ($1.value(forKey:"firstName") as! String);
               }else{
                    return ($0.value(forKey: "lastName") as! String) < ($1.value(forKey:"lastName") as! String);
                }
            }
            return (UIApplication.shared.delegate as! AppDelegate).employees.count;
        }else{
            return 0;
        }
    }
   
    //  Returns cells for tableview to display
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let deptIndex = indexPath.row
        let empIndex = indexPath.row
        var display : String;
        if(tableView == departmentTable){
            let departments = sortDepartments;
            display = Array(departments)[deptIndex].value(forKey:"name") as! String
        }else if(tableView == employeeTable){
            let employees = sortEmployees;
            let displayLast = Array(employees)[empIndex].value(forKey: "lastName") as! String
            let displayFirst =  Array(employees)[empIndex].value(forKey: "firstName") as! String;
            display = displayLast + ", " + displayFirst
        }else{
            display = "";
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "defaultCell", for: indexPath)
           
        // Configure the cell’s contents.
        cell.textLabel!.text = display
        return cell
   }
    
}

