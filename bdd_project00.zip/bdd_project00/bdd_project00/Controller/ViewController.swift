//
//  ViewController.swift
//  bdd_project00
//
//  Created by BDDave on 2/1/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet var attackField : UITextField?
    @IBOutlet var defenseField : UITextField?
    @IBOutlet var damageLabel : UILabel?
    @IBAction func generateButton(sender: UIButton){
        let randomNum = Int.random(in:0..<100);
        let textField = attackField;
        textField?.text = String(randomNum);
        m_DamageModel.setAttack(Int32(randomNum))
        damageLabel?.text = m_DamageModel.getDamage();
    }
    
    private var m_DamageModel = Damage();  // Create a new Model based from Model data
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if(textField == attackField){
            textField.becomeFirstResponder();
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if (textField == attackField){
            var inputAttack = textField.text;
            if(inputAttack == ""){
                inputAttack = "0";
                textField.text = "0";
            }
            let intAttack = Int32(inputAttack!);
            m_DamageModel.setAttack(intAttack!);
        }
        
        if(textField == defenseField){
            var inputDefense = textField.text;
            if(inputDefense == ""){
                inputDefense = "0";
                textField.text = "0";
            }
            let intDefense = Int32(inputDefense!);
            m_DamageModel.setDefense(intDefense!);
        }
        
        damageLabel?.text = m_DamageModel.getDamage();
        
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
    
    }
    
}

