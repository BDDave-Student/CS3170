//
//  AppDelegate.swift
//  bdd_project00
//
//  Created by BDDave on 2/1/21.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

}
