//
//  ConvertMeasurements.swift
//  bdd_project00
//
//  Created by BDDave on 2/1/21.
//

import Foundation

class Damage{
    // Model Data for converting measurements
    var m_attack: Int32 = 0;
    var m_defense: Int32 = 0;
    
    // Model constructor
    public func Damage(_ a: Int32, _ d: Int32 ){
        m_attack = a;
        m_defense = d;
    }
    // Model function to calculate damage
    // based on Attack and Defense
    public func getAttack() -> Int32{
        return m_attack;
    }
    
    public func setAttack(_ a: Int32){
        self.m_attack = a;
    }
    
    public func getDefense() -> Int32{
        return m_defense;
    }
    
    public func setDefense(_ d: Int32){
        self.m_defense = d;
    }
    
    public func getDamage() -> String{
        if(m_defense >= m_attack){
            return "0";
        } else{
            return String(m_attack - m_defense);
            
        }
    }
}
