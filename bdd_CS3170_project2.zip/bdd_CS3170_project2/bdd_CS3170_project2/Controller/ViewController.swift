//
//  ViewController.swift
//  bdd_CS3170_project2
//
//  Created by BDDave on 3/12/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var recordPlayer: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad();
        // Do any additional setup after loading the view.
       
    }
    //  UIBezierPath
    func draw(_ rect: CGRect) {
        let path = UIBezierPath(rect: rect)
        UIColor.red.setFill();
        UIColor.black.setStroke();
        path.lineWidth = 20.0;
        path.stroke();
    }
    
    //  Image Controller
    @IBOutlet var vinylImage : UIImageView!;
    @IBOutlet var blueImage : UIImageView!;
    var radiansToRotate = CGFloat(0);
    var setOpacity = CGFloat(0);
    
    func update(){
        radiansToRotate += 0.1;
        vinylImage.transform = CGAffineTransform(rotationAngle: radiansToRotate);
        blueImage.transform = CGAffineTransform(rotationAngle: radiansToRotate);
        DispatchQueue.main.asyncAfter(deadline: .now() + 1){
            self.update();
            self.swap();
        }
    }
    
    var isOffset = true;
    func swap(){
        if(isOffset == true){
            setOpacity -= 0.01;
            if(setOpacity <= 0){
                isOffset = false;
            }
        }else{
            setOpacity += 0.01;
            if(setOpacity >= 1){
                isOffset = true;
            }
        }
        
        if (blueImage.isHidden == true){
            //  Hide black image, show blue image
            blueImage.alpha += setOpacity;
            vinylImage.alpha -= setOpacity;
            if(vinylImage.alpha <= 0){
                vinylImage.isHidden = true;
                blueImage.isHidden = false;
            }
        }else{
            //  Default:  Hide blue image, show black image
            vinylImage.alpha += setOpacity;
            blueImage.alpha -= setOpacity;
            if(blueImage.alpha <= 0){
                blueImage.isHidden = true;
                vinylImage.isHidden = false;
            }
        }
    }
    //  Button Controller
    @IBOutlet var playButton : UIButton?;
    var isSpinning = false;
    @IBAction func spinTapped(_ sender: UIButton){
        if(sender == playButton){
                update();
            
        }
    }
}

