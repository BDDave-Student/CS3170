//
//  BezierPath.swift
//  bdd_CS3170_project2
//
//  Created by BDDave on 4/20/21.
//

import SwiftUI
import UIKit

class BezierPath : UIView {
    var setWidth = 10.0;
    var isOffset = true;
    
    func update() {
        if(isOffset == true){
            setWidth += 10.0;
            if(setWidth == 150){
                isOffset = false;
            }
        }else{
            setWidth -= 10.0;
            if(setWidth == 0){
                isOffset = true;
            }
        }
        print(setWidth);
        setNeedsDisplay();
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            self.update()
        }
   }
   
   override func awakeFromNib() {
      update()
   }


    override func draw(_ rect: CGRect) {
        let circPath = UIBezierPath(ovalIn: rect);
        let customColor = UIColor(red: 0, green: 220, blue: 222, alpha: 1);
        customColor.setFill();
        circPath.fill();
        circPath.lineWidth += CGFloat(setWidth);
        UIColor.black.setStroke();
        circPath.stroke();
   }
    

}

